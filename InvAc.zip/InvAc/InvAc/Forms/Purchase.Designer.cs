﻿namespace InvAc.Forms
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Purchase));
            this.panel1 = new System.Windows.Forms.Panel();
            this.PictureExit = new System.Windows.Forms.PictureBox();
            this.LeftBack = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TextBoxSumm1 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm6 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm10 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm9 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm8 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm7 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm5 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.inventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vedenie_UchetaDataSet1 = new InvAc.Vedenie_UchetaDataSet1();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.inventoryTableAdapter = new InvAc.Vedenie_UchetaDataSet1TableAdapters.InventoryTableAdapter();
            this.providerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKPurchaseInventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.purchaseTableAdapter = new InvAc.Vedenie_UchetaDataSet1TableAdapters.PurchaseTableAdapter();
            this.providerTableAdapter = new InvAc.Vedenie_UchetaDataSet1TableAdapters.ProviderTableAdapter();
            this.label6 = new System.Windows.Forms.Label();
            this.TextBoxOrganization = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TextBoxNomer = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.TextBoxPrice1 = new System.Windows.Forms.TextBox();
            this.ComboBoxProvider = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TextBoxNameInventory1 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory2 = new System.Windows.Forms.TextBox();
            this.ButtonNew2 = new System.Windows.Forms.Button();
            this.ButtonNew3 = new System.Windows.Forms.Button();
            this.TextBoxNameInventory3 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory4 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory5 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory6 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory7 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory8 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory9 = new System.Windows.Forms.TextBox();
            this.TextBoxNameInventory10 = new System.Windows.Forms.TextBox();
            this.ButtonNew10 = new System.Windows.Forms.Button();
            this.ButtonNew8 = new System.Windows.Forms.Button();
            this.ButtonNew7 = new System.Windows.Forms.Button();
            this.ButtonNew9 = new System.Windows.Forms.Button();
            this.ButtonNew4 = new System.Windows.Forms.Button();
            this.ButtonNew6 = new System.Windows.Forms.Button();
            this.ButtonNew5 = new System.Windows.Forms.Button();
            this.TextBoxKolvo1 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo10 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo9 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo8 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo7 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo6 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo5 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo4 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo3 = new System.Windows.Forms.TextBox();
            this.TextBoxKolvo2 = new System.Windows.Forms.TextBox();
            this.TextBoxItog = new System.Windows.Forms.TextBox();
            this.TextBoxPrice4 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice3 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice5 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice6 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice7 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice10 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice2 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice8 = new System.Windows.Forms.TextBox();
            this.TextBoxPrice9 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm4 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm3 = new System.Windows.Forms.TextBox();
            this.TextBoxSumm2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vedenie_UchetaDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.providerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPurchaseInventoryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.panel1.Controls.Add(this.PictureExit);
            this.panel1.Controls.Add(this.LeftBack);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.TextBoxSumm1);
            this.panel1.Controls.Add(this.TextBoxSumm6);
            this.panel1.Controls.Add(this.TextBoxSumm10);
            this.panel1.Controls.Add(this.TextBoxSumm9);
            this.panel1.Controls.Add(this.TextBoxSumm8);
            this.panel1.Controls.Add(this.TextBoxSumm7);
            this.panel1.Controls.Add(this.TextBoxSumm5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1542, 100);
            this.panel1.TabIndex = 0;
            // 
            // PictureExit
            // 
            this.PictureExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureExit.Image = global::InvAc.Properties.Resources.Exit;
            this.PictureExit.Location = new System.Drawing.Point(1504, 0);
            this.PictureExit.Name = "PictureExit";
            this.PictureExit.Size = new System.Drawing.Size(35, 35);
            this.PictureExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureExit.TabIndex = 30;
            this.PictureExit.TabStop = false;
            this.PictureExit.Click += new System.EventHandler(this.PictureExit_Click);
            // 
            // LeftBack
            // 
            this.LeftBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LeftBack.Image = global::InvAc.Properties.Resources.Left;
            this.LeftBack.Location = new System.Drawing.Point(0, 0);
            this.LeftBack.Name = "LeftBack";
            this.LeftBack.Size = new System.Drawing.Size(35, 35);
            this.LeftBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LeftBack.TabIndex = 29;
            this.LeftBack.TabStop = false;
            this.LeftBack.Click += new System.EventHandler(this.LeftBack_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::InvAc.Properties.Resources.LogoMaker;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(179, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Century", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1542, 100);
            this.label1.TabIndex = 0;
            this.label1.Text = "Создание накладной";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TextBoxSumm1
            // 
            this.TextBoxSumm1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm1.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm1.Location = new System.Drawing.Point(1222, 49);
            this.TextBoxSumm1.Name = "TextBoxSumm1";
            this.TextBoxSumm1.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm1.TabIndex = 65;
            this.TextBoxSumm1.Visible = false;
            // 
            // TextBoxSumm6
            // 
            this.TextBoxSumm6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm6.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm6.Location = new System.Drawing.Point(1111, 46);
            this.TextBoxSumm6.Name = "TextBoxSumm6";
            this.TextBoxSumm6.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm6.TabIndex = 70;
            this.TextBoxSumm6.Visible = false;
            // 
            // TextBoxSumm10
            // 
            this.TextBoxSumm10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm10.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm10.Location = new System.Drawing.Point(1111, 166);
            this.TextBoxSumm10.Name = "TextBoxSumm10";
            this.TextBoxSumm10.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm10.TabIndex = 66;
            this.TextBoxSumm10.Visible = false;
            // 
            // TextBoxSumm9
            // 
            this.TextBoxSumm9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm9.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm9.Location = new System.Drawing.Point(1111, 136);
            this.TextBoxSumm9.Name = "TextBoxSumm9";
            this.TextBoxSumm9.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm9.TabIndex = 67;
            this.TextBoxSumm9.Visible = false;
            // 
            // TextBoxSumm8
            // 
            this.TextBoxSumm8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm8.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm8.Location = new System.Drawing.Point(1111, 106);
            this.TextBoxSumm8.Name = "TextBoxSumm8";
            this.TextBoxSumm8.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm8.TabIndex = 68;
            this.TextBoxSumm8.Visible = false;
            // 
            // TextBoxSumm7
            // 
            this.TextBoxSumm7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm7.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm7.Location = new System.Drawing.Point(1111, 76);
            this.TextBoxSumm7.Name = "TextBoxSumm7";
            this.TextBoxSumm7.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm7.TabIndex = 69;
            this.TextBoxSumm7.Visible = false;
            // 
            // TextBoxSumm5
            // 
            this.TextBoxSumm5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm5.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm5.Location = new System.Drawing.Point(1111, 16);
            this.TextBoxSumm5.Name = "TextBoxSumm5";
            this.TextBoxSumm5.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm5.TabIndex = 71;
            this.TextBoxSumm5.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label2.Location = new System.Drawing.Point(785, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(272, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Название инвентаря";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label3.Location = new System.Drawing.Point(785, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(296, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Количество инвентаря";
            // 
            // inventoryBindingSource
            // 
            this.inventoryBindingSource.DataMember = "Inventory";
            this.inventoryBindingSource.DataSource = this.vedenie_UchetaDataSet1;
            // 
            // vedenie_UchetaDataSet1
            // 
            this.vedenie_UchetaDataSet1.DataSetName = "Vedenie_UchetaDataSet1";
            this.vedenie_UchetaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label4.Location = new System.Drawing.Point(12, 388);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 28);
            this.label4.TabIndex = 5;
            this.label4.Text = "Поставщик";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label5.Location = new System.Drawing.Point(692, 507);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 28);
            this.label5.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.button1.Font = new System.Drawing.Font("Century", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.button1.Location = new System.Drawing.Point(552, 633);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(430, 71);
            this.button1.TabIndex = 8;
            this.button1.Text = "Создать накладную";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // inventoryTableAdapter
            // 
            this.inventoryTableAdapter.ClearBeforeFill = true;
            // 
            // providerBindingSource
            // 
            this.providerBindingSource.DataMember = "Provider";
            this.providerBindingSource.DataSource = this.vedenie_UchetaDataSet1;
            // 
            // fKPurchaseInventoryBindingSource
            // 
            this.fKPurchaseInventoryBindingSource.DataMember = "FK_Purchase_Inventory";
            this.fKPurchaseInventoryBindingSource.DataSource = this.inventoryBindingSource;
            // 
            // purchaseTableAdapter
            // 
            this.purchaseTableAdapter.ClearBeforeFill = true;
            // 
            // providerTableAdapter
            // 
            this.providerTableAdapter.ClearBeforeFill = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label6.Location = new System.Drawing.Point(12, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(300, 28);
            this.label6.TabIndex = 12;
            this.label6.Text = "Название организации";
            // 
            // TextBoxOrganization
            // 
            this.TextBoxOrganization.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxOrganization.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxOrganization.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxOrganization.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxOrganization.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxOrganization.Location = new System.Drawing.Point(332, 236);
            this.TextBoxOrganization.Name = "TextBoxOrganization";
            this.TextBoxOrganization.Size = new System.Drawing.Size(266, 35);
            this.TextBoxOrganization.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label7.Location = new System.Drawing.Point(10, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(235, 28);
            this.label7.TabIndex = 16;
            this.label7.Text = "Номер накладной";
            // 
            // TextBoxNomer
            // 
            this.TextBoxNomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNomer.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNomer.Location = new System.Drawing.Point(332, 150);
            this.TextBoxNomer.Name = "TextBoxNomer";
            this.TextBoxNomer.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNomer.TabIndex = 17;
            this.TextBoxNomer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNomer_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label8.Location = new System.Drawing.Point(12, 314);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 28);
            this.label8.TabIndex = 18;
            this.label8.Text = "Дата доставки";
            // 
            // DateTimePicker
            // 
            this.DateTimePicker.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.DateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.DateTimePicker.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.DateTimePicker.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.DateTimePicker.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePicker.Location = new System.Drawing.Point(332, 318);
            this.DateTimePicker.Name = "DateTimePicker";
            this.DateTimePicker.Size = new System.Drawing.Size(266, 35);
            this.DateTimePicker.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label9.Location = new System.Drawing.Point(785, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(216, 28);
            this.label9.TabIndex = 21;
            this.label9.Text = "Цена инвентаря";
            // 
            // TextBoxPrice1
            // 
            this.TextBoxPrice1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice1.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice1.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice1.Name = "TextBoxPrice1";
            this.TextBoxPrice1.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice1.TabIndex = 22;
            this.TextBoxPrice1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice1_KeyPress);
            // 
            // ComboBoxProvider
            // 
            this.ComboBoxProvider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.ComboBoxProvider.DataSource = this.providerBindingSource;
            this.ComboBoxProvider.DisplayMember = "NameProvider";
            this.ComboBoxProvider.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ComboBoxProvider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ComboBoxProvider.FormattingEnabled = true;
            this.ComboBoxProvider.Location = new System.Drawing.Point(332, 395);
            this.ComboBoxProvider.Name = "ComboBoxProvider";
            this.ComboBoxProvider.Size = new System.Drawing.Size(266, 36);
            this.ComboBoxProvider.TabIndex = 23;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 802);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1542, 100);
            this.panel2.TabIndex = 25;
            // 
            // TextBoxNameInventory1
            // 
            this.TextBoxNameInventory1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory1.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory1.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory1.Name = "TextBoxNameInventory1";
            this.TextBoxNameInventory1.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory1.TabIndex = 26;
            // 
            // TextBoxNameInventory2
            // 
            this.TextBoxNameInventory2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory2.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory2.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory2.Name = "TextBoxNameInventory2";
            this.TextBoxNameInventory2.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory2.TabIndex = 27;
            this.TextBoxNameInventory2.Visible = false;
            // 
            // ButtonNew2
            // 
            this.ButtonNew2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew2.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew2.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew2.Name = "ButtonNew2";
            this.ButtonNew2.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew2.TabIndex = 28;
            this.ButtonNew2.Text = "Внести в накладную";
            this.ButtonNew2.UseVisualStyleBackColor = false;
            this.ButtonNew2.Click += new System.EventHandler(this.ButtonNew2_Click);
            // 
            // ButtonNew3
            // 
            this.ButtonNew3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew3.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew3.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew3.Name = "ButtonNew3";
            this.ButtonNew3.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew3.TabIndex = 29;
            this.ButtonNew3.Text = "Внести в накладную";
            this.ButtonNew3.UseVisualStyleBackColor = false;
            this.ButtonNew3.Visible = false;
            this.ButtonNew3.Click += new System.EventHandler(this.ButtonNew3_Click);
            // 
            // TextBoxNameInventory3
            // 
            this.TextBoxNameInventory3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory3.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory3.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory3.Name = "TextBoxNameInventory3";
            this.TextBoxNameInventory3.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory3.TabIndex = 30;
            this.TextBoxNameInventory3.Visible = false;
            // 
            // TextBoxNameInventory4
            // 
            this.TextBoxNameInventory4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory4.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory4.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory4.Name = "TextBoxNameInventory4";
            this.TextBoxNameInventory4.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory4.TabIndex = 31;
            this.TextBoxNameInventory4.Visible = false;
            // 
            // TextBoxNameInventory5
            // 
            this.TextBoxNameInventory5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory5.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory5.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory5.Name = "TextBoxNameInventory5";
            this.TextBoxNameInventory5.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory5.TabIndex = 32;
            this.TextBoxNameInventory5.Visible = false;
            // 
            // TextBoxNameInventory6
            // 
            this.TextBoxNameInventory6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory6.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory6.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory6.Name = "TextBoxNameInventory6";
            this.TextBoxNameInventory6.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory6.TabIndex = 33;
            this.TextBoxNameInventory6.Visible = false;
            // 
            // TextBoxNameInventory7
            // 
            this.TextBoxNameInventory7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory7.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory7.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory7.Name = "TextBoxNameInventory7";
            this.TextBoxNameInventory7.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory7.TabIndex = 34;
            this.TextBoxNameInventory7.Visible = false;
            // 
            // TextBoxNameInventory8
            // 
            this.TextBoxNameInventory8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory8.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory8.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory8.Name = "TextBoxNameInventory8";
            this.TextBoxNameInventory8.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory8.TabIndex = 35;
            this.TextBoxNameInventory8.Visible = false;
            // 
            // TextBoxNameInventory9
            // 
            this.TextBoxNameInventory9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory9.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory9.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory9.Name = "TextBoxNameInventory9";
            this.TextBoxNameInventory9.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory9.TabIndex = 36;
            this.TextBoxNameInventory9.Visible = false;
            // 
            // TextBoxNameInventory10
            // 
            this.TextBoxNameInventory10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxNameInventory10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxNameInventory10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxNameInventory10.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxNameInventory10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxNameInventory10.Location = new System.Drawing.Point(1091, 157);
            this.TextBoxNameInventory10.Name = "TextBoxNameInventory10";
            this.TextBoxNameInventory10.Size = new System.Drawing.Size(266, 35);
            this.TextBoxNameInventory10.TabIndex = 37;
            this.TextBoxNameInventory10.Visible = false;
            // 
            // ButtonNew10
            // 
            this.ButtonNew10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew10.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew10.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew10.Name = "ButtonNew10";
            this.ButtonNew10.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew10.TabIndex = 38;
            this.ButtonNew10.Text = "Внести в накладную";
            this.ButtonNew10.UseVisualStyleBackColor = false;
            this.ButtonNew10.Visible = false;
            this.ButtonNew10.Click += new System.EventHandler(this.ButtonNew10_Click);
            // 
            // ButtonNew8
            // 
            this.ButtonNew8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew8.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew8.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew8.Name = "ButtonNew8";
            this.ButtonNew8.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew8.TabIndex = 39;
            this.ButtonNew8.Text = "Внести в накладную";
            this.ButtonNew8.UseVisualStyleBackColor = false;
            this.ButtonNew8.Visible = false;
            this.ButtonNew8.Click += new System.EventHandler(this.ButtonNew8_Click);
            // 
            // ButtonNew7
            // 
            this.ButtonNew7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew7.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew7.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew7.Name = "ButtonNew7";
            this.ButtonNew7.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew7.TabIndex = 40;
            this.ButtonNew7.Text = "Внести в накладную";
            this.ButtonNew7.UseVisualStyleBackColor = false;
            this.ButtonNew7.Visible = false;
            this.ButtonNew7.Click += new System.EventHandler(this.ButtonNew7_Click);
            // 
            // ButtonNew9
            // 
            this.ButtonNew9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew9.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew9.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew9.Name = "ButtonNew9";
            this.ButtonNew9.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew9.TabIndex = 41;
            this.ButtonNew9.Text = "Внести в накладную";
            this.ButtonNew9.UseVisualStyleBackColor = false;
            this.ButtonNew9.Visible = false;
            this.ButtonNew9.Click += new System.EventHandler(this.ButtonNew9_Click);
            // 
            // ButtonNew4
            // 
            this.ButtonNew4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew4.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew4.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew4.Name = "ButtonNew4";
            this.ButtonNew4.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew4.TabIndex = 42;
            this.ButtonNew4.Text = "Внести в накладную";
            this.ButtonNew4.UseVisualStyleBackColor = false;
            this.ButtonNew4.Visible = false;
            this.ButtonNew4.Click += new System.EventHandler(this.ButtonNew4_Click);
            // 
            // ButtonNew6
            // 
            this.ButtonNew6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew6.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew6.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew6.Name = "ButtonNew6";
            this.ButtonNew6.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew6.TabIndex = 43;
            this.ButtonNew6.Text = "Внести в накладную";
            this.ButtonNew6.UseVisualStyleBackColor = false;
            this.ButtonNew6.Visible = false;
            this.ButtonNew6.Click += new System.EventHandler(this.ButtonNew6_Click);
            // 
            // ButtonNew5
            // 
            this.ButtonNew5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(109)))), ((int)(((byte)(156)))));
            this.ButtonNew5.Font = new System.Drawing.Font("Century", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ButtonNew5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.ButtonNew5.Location = new System.Drawing.Point(1368, 157);
            this.ButtonNew5.Name = "ButtonNew5";
            this.ButtonNew5.Size = new System.Drawing.Size(162, 117);
            this.ButtonNew5.TabIndex = 44;
            this.ButtonNew5.Text = "Внести в накладную";
            this.ButtonNew5.UseVisualStyleBackColor = false;
            this.ButtonNew5.Visible = false;
            this.ButtonNew5.Click += new System.EventHandler(this.ButtonNew5_Click);
            // 
            // TextBoxKolvo1
            // 
            this.TextBoxKolvo1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo1.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo1.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo1.Name = "TextBoxKolvo1";
            this.TextBoxKolvo1.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo1.TabIndex = 45;
            this.TextBoxKolvo1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo1_KeyPress);
            // 
            // TextBoxKolvo10
            // 
            this.TextBoxKolvo10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo10.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo10.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo10.Name = "TextBoxKolvo10";
            this.TextBoxKolvo10.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo10.TabIndex = 46;
            this.TextBoxKolvo10.Visible = false;
            this.TextBoxKolvo10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo10_KeyPress);
            // 
            // TextBoxKolvo9
            // 
            this.TextBoxKolvo9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo9.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo9.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo9.Name = "TextBoxKolvo9";
            this.TextBoxKolvo9.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo9.TabIndex = 47;
            this.TextBoxKolvo9.Visible = false;
            this.TextBoxKolvo9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo9_KeyPress);
            // 
            // TextBoxKolvo8
            // 
            this.TextBoxKolvo8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo8.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo8.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo8.Name = "TextBoxKolvo8";
            this.TextBoxKolvo8.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo8.TabIndex = 48;
            this.TextBoxKolvo8.Visible = false;
            this.TextBoxKolvo8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo8_KeyPress);
            // 
            // TextBoxKolvo7
            // 
            this.TextBoxKolvo7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo7.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo7.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo7.Name = "TextBoxKolvo7";
            this.TextBoxKolvo7.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo7.TabIndex = 49;
            this.TextBoxKolvo7.Visible = false;
            this.TextBoxKolvo7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo7_KeyPress);
            // 
            // TextBoxKolvo6
            // 
            this.TextBoxKolvo6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo6.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo6.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo6.Name = "TextBoxKolvo6";
            this.TextBoxKolvo6.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo6.TabIndex = 50;
            this.TextBoxKolvo6.Visible = false;
            this.TextBoxKolvo6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo6_KeyPress);
            // 
            // TextBoxKolvo5
            // 
            this.TextBoxKolvo5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo5.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo5.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo5.Name = "TextBoxKolvo5";
            this.TextBoxKolvo5.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo5.TabIndex = 51;
            this.TextBoxKolvo5.Visible = false;
            this.TextBoxKolvo5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo5_KeyPress);
            // 
            // TextBoxKolvo4
            // 
            this.TextBoxKolvo4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo4.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo4.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo4.Name = "TextBoxKolvo4";
            this.TextBoxKolvo4.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo4.TabIndex = 52;
            this.TextBoxKolvo4.Visible = false;
            this.TextBoxKolvo4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo4_KeyPress);
            // 
            // TextBoxKolvo3
            // 
            this.TextBoxKolvo3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo3.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo3.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo3.Name = "TextBoxKolvo3";
            this.TextBoxKolvo3.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo3.TabIndex = 53;
            this.TextBoxKolvo3.Visible = false;
            this.TextBoxKolvo3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo3_KeyPress);
            // 
            // TextBoxKolvo2
            // 
            this.TextBoxKolvo2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxKolvo2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxKolvo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxKolvo2.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxKolvo2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxKolvo2.Location = new System.Drawing.Point(1091, 236);
            this.TextBoxKolvo2.Name = "TextBoxKolvo2";
            this.TextBoxKolvo2.Size = new System.Drawing.Size(266, 35);
            this.TextBoxKolvo2.TabIndex = 54;
            this.TextBoxKolvo2.Visible = false;
            this.TextBoxKolvo2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxKolvo2_KeyPress);
            // 
            // TextBoxItog
            // 
            this.TextBoxItog.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxItog.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxItog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxItog.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxItog.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxItog.Location = new System.Drawing.Point(791, 601);
            this.TextBoxItog.Name = "TextBoxItog";
            this.TextBoxItog.Size = new System.Drawing.Size(189, 24);
            this.TextBoxItog.TabIndex = 55;
            this.TextBoxItog.TextChanged += new System.EventHandler(this.TextBoxItog_TextChanged);
            // 
            // TextBoxPrice4
            // 
            this.TextBoxPrice4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice4.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice4.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice4.Name = "TextBoxPrice4";
            this.TextBoxPrice4.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice4.TabIndex = 56;
            this.TextBoxPrice4.Visible = false;
            this.TextBoxPrice4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice4_KeyPress);
            // 
            // TextBoxPrice3
            // 
            this.TextBoxPrice3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice3.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice3.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice3.Name = "TextBoxPrice3";
            this.TextBoxPrice3.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice3.TabIndex = 57;
            this.TextBoxPrice3.Visible = false;
            this.TextBoxPrice3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice3_KeyPress);
            // 
            // TextBoxPrice5
            // 
            this.TextBoxPrice5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice5.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice5.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice5.Name = "TextBoxPrice5";
            this.TextBoxPrice5.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice5.TabIndex = 58;
            this.TextBoxPrice5.Visible = false;
            this.TextBoxPrice5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice5_KeyPress);
            // 
            // TextBoxPrice6
            // 
            this.TextBoxPrice6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice6.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice6.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice6.Name = "TextBoxPrice6";
            this.TextBoxPrice6.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice6.TabIndex = 59;
            this.TextBoxPrice6.Visible = false;
            this.TextBoxPrice6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice6_KeyPress);
            // 
            // TextBoxPrice7
            // 
            this.TextBoxPrice7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice7.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice7.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice7.Name = "TextBoxPrice7";
            this.TextBoxPrice7.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice7.TabIndex = 60;
            this.TextBoxPrice7.Visible = false;
            this.TextBoxPrice7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice7_KeyPress);
            // 
            // TextBoxPrice10
            // 
            this.TextBoxPrice10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice10.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice10.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice10.Name = "TextBoxPrice10";
            this.TextBoxPrice10.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice10.TabIndex = 61;
            this.TextBoxPrice10.Visible = false;
            this.TextBoxPrice10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice10_KeyPress);
            // 
            // TextBoxPrice2
            // 
            this.TextBoxPrice2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice2.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice2.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice2.Name = "TextBoxPrice2";
            this.TextBoxPrice2.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice2.TabIndex = 62;
            this.TextBoxPrice2.Visible = false;
            this.TextBoxPrice2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice2_KeyPress);
            // 
            // TextBoxPrice8
            // 
            this.TextBoxPrice8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice8.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice8.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice8.Name = "TextBoxPrice8";
            this.TextBoxPrice8.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice8.TabIndex = 63;
            this.TextBoxPrice8.Visible = false;
            this.TextBoxPrice8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice8_KeyPress);
            // 
            // TextBoxPrice9
            // 
            this.TextBoxPrice9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxPrice9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxPrice9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxPrice9.Font = new System.Drawing.Font("Century", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBoxPrice9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxPrice9.Location = new System.Drawing.Point(1091, 321);
            this.TextBoxPrice9.Name = "TextBoxPrice9";
            this.TextBoxPrice9.Size = new System.Drawing.Size(266, 35);
            this.TextBoxPrice9.TabIndex = 64;
            this.TextBoxPrice9.Visible = false;
            this.TextBoxPrice9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxPrice9_KeyPress);
            // 
            // TextBoxSumm4
            // 
            this.TextBoxSumm4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm4.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm4.Location = new System.Drawing.Point(1172, 46);
            this.TextBoxSumm4.Name = "TextBoxSumm4";
            this.TextBoxSumm4.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm4.TabIndex = 72;
            this.TextBoxSumm4.Visible = false;
            // 
            // TextBoxSumm3
            // 
            this.TextBoxSumm3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm3.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm3.Location = new System.Drawing.Point(1172, 16);
            this.TextBoxSumm3.Name = "TextBoxSumm3";
            this.TextBoxSumm3.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm3.TabIndex = 73;
            this.TextBoxSumm3.Visible = false;
            // 
            // TextBoxSumm2
            // 
            this.TextBoxSumm2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TextBoxSumm2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBoxSumm2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(147)))), ((int)(((byte)(156)))));
            this.TextBoxSumm2.Font = new System.Drawing.Font("Century", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.TextBoxSumm2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.TextBoxSumm2.Location = new System.Drawing.Point(1197, 33);
            this.TextBoxSumm2.Name = "TextBoxSumm2";
            this.TextBoxSumm2.Size = new System.Drawing.Size(10, 24);
            this.TextBoxSumm2.TabIndex = 74;
            this.TextBoxSumm2.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(204)))), ((int)(((byte)(140)))));
            this.label10.Location = new System.Drawing.Point(546, 592);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(239, 33);
            this.label10.TabIndex = 75;
            this.label10.Text = "Итоговая сумма";
            // 
            // Purchase
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(82)))), ((int)(((byte)(116)))));
            this.ClientSize = new System.Drawing.Size(1542, 902);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TextBoxItog);
            this.Controls.Add(this.TextBoxKolvo1);
            this.Controls.Add(this.ButtonNew2);
            this.Controls.Add(this.TextBoxNameInventory1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.ComboBoxProvider);
            this.Controls.Add(this.TextBoxPrice1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.DateTimePicker);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TextBoxNomer);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TextBoxOrganization);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TextBoxNameInventory2);
            this.Controls.Add(this.ButtonNew3);
            this.Controls.Add(this.TextBoxNameInventory3);
            this.Controls.Add(this.TextBoxNameInventory4);
            this.Controls.Add(this.TextBoxNameInventory5);
            this.Controls.Add(this.TextBoxNameInventory6);
            this.Controls.Add(this.TextBoxNameInventory7);
            this.Controls.Add(this.TextBoxNameInventory8);
            this.Controls.Add(this.TextBoxNameInventory9);
            this.Controls.Add(this.TextBoxNameInventory10);
            this.Controls.Add(this.ButtonNew4);
            this.Controls.Add(this.ButtonNew5);
            this.Controls.Add(this.ButtonNew6);
            this.Controls.Add(this.ButtonNew7);
            this.Controls.Add(this.ButtonNew8);
            this.Controls.Add(this.ButtonNew9);
            this.Controls.Add(this.ButtonNew10);
            this.Controls.Add(this.TextBoxKolvo2);
            this.Controls.Add(this.TextBoxKolvo3);
            this.Controls.Add(this.TextBoxKolvo4);
            this.Controls.Add(this.TextBoxKolvo5);
            this.Controls.Add(this.TextBoxKolvo6);
            this.Controls.Add(this.TextBoxKolvo7);
            this.Controls.Add(this.TextBoxKolvo8);
            this.Controls.Add(this.TextBoxKolvo9);
            this.Controls.Add(this.TextBoxKolvo10);
            this.Controls.Add(this.TextBoxPrice2);
            this.Controls.Add(this.TextBoxPrice3);
            this.Controls.Add(this.TextBoxPrice4);
            this.Controls.Add(this.TextBoxPrice5);
            this.Controls.Add(this.TextBoxPrice6);
            this.Controls.Add(this.TextBoxPrice7);
            this.Controls.Add(this.TextBoxPrice8);
            this.Controls.Add(this.TextBoxPrice9);
            this.Controls.Add(this.TextBoxPrice10);
            this.Controls.Add(this.TextBoxSumm2);
            this.Controls.Add(this.TextBoxSumm3);
            this.Controls.Add(this.TextBoxSumm4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Purchase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Purchase_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vedenie_UchetaDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.providerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPurchaseInventoryBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox PictureExit;
        private System.Windows.Forms.PictureBox LeftBack;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private Vedenie_UchetaDataSet1 vedenie_UchetaDataSet1;
        private System.Windows.Forms.BindingSource inventoryBindingSource;
        private Vedenie_UchetaDataSet1TableAdapters.InventoryTableAdapter inventoryTableAdapter;
        private System.Windows.Forms.BindingSource fKPurchaseInventoryBindingSource;
        private Vedenie_UchetaDataSet1TableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        private System.Windows.Forms.BindingSource providerBindingSource;
        private Vedenie_UchetaDataSet1TableAdapters.ProviderTableAdapter providerTableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TextBoxOrganization;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TextBoxNomer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker DateTimePicker;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TextBoxPrice1;
        private System.Windows.Forms.ComboBox ComboBoxProvider;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox TextBoxNameInventory1;
        private System.Windows.Forms.TextBox TextBoxNameInventory2;
        private System.Windows.Forms.Button ButtonNew2;
        private System.Windows.Forms.Button ButtonNew3;
        private System.Windows.Forms.TextBox TextBoxNameInventory3;
        private System.Windows.Forms.TextBox TextBoxNameInventory4;
        private System.Windows.Forms.TextBox TextBoxNameInventory5;
        private System.Windows.Forms.TextBox TextBoxNameInventory6;
        private System.Windows.Forms.TextBox TextBoxNameInventory7;
        private System.Windows.Forms.TextBox TextBoxNameInventory8;
        private System.Windows.Forms.TextBox TextBoxNameInventory9;
        private System.Windows.Forms.TextBox TextBoxNameInventory10;
        private System.Windows.Forms.Button ButtonNew10;
        private System.Windows.Forms.Button ButtonNew8;
        private System.Windows.Forms.Button ButtonNew7;
        private System.Windows.Forms.Button ButtonNew9;
        private System.Windows.Forms.Button ButtonNew4;
        private System.Windows.Forms.Button ButtonNew6;
        private System.Windows.Forms.Button ButtonNew5;
        private System.Windows.Forms.TextBox TextBoxKolvo1;
        private System.Windows.Forms.TextBox TextBoxKolvo10;
        private System.Windows.Forms.TextBox TextBoxKolvo9;
        private System.Windows.Forms.TextBox TextBoxKolvo8;
        private System.Windows.Forms.TextBox TextBoxKolvo7;
        private System.Windows.Forms.TextBox TextBoxKolvo6;
        private System.Windows.Forms.TextBox TextBoxKolvo5;
        private System.Windows.Forms.TextBox TextBoxKolvo4;
        private System.Windows.Forms.TextBox TextBoxKolvo3;
        private System.Windows.Forms.TextBox TextBoxKolvo2;
        private System.Windows.Forms.TextBox TextBoxItog;
        private System.Windows.Forms.TextBox TextBoxPrice4;
        private System.Windows.Forms.TextBox TextBoxPrice3;
        private System.Windows.Forms.TextBox TextBoxPrice5;
        private System.Windows.Forms.TextBox TextBoxPrice6;
        private System.Windows.Forms.TextBox TextBoxPrice7;
        private System.Windows.Forms.TextBox TextBoxPrice10;
        private System.Windows.Forms.TextBox TextBoxPrice2;
        private System.Windows.Forms.TextBox TextBoxPrice8;
        private System.Windows.Forms.TextBox TextBoxPrice9;
        private System.Windows.Forms.TextBox TextBoxSumm1;
        private System.Windows.Forms.TextBox TextBoxSumm10;
        private System.Windows.Forms.TextBox TextBoxSumm9;
        private System.Windows.Forms.TextBox TextBoxSumm8;
        private System.Windows.Forms.TextBox TextBoxSumm7;
        private System.Windows.Forms.TextBox TextBoxSumm6;
        private System.Windows.Forms.TextBox TextBoxSumm5;
        private System.Windows.Forms.TextBox TextBoxSumm4;
        private System.Windows.Forms.TextBox TextBoxSumm3;
        private System.Windows.Forms.TextBox TextBoxSumm2;
        private System.Windows.Forms.Label label10;
    }
}