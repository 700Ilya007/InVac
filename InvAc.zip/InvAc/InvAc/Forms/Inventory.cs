﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Printing;

namespace InvAc.Forms
{

   enum RowState
    {
        Existed,
        New,
        Modfield,
        ModfieldNew,
        Deleted
    }
    public partial class Inventory : Form
    {
        public readonly checkUser _user;
        DataBase dataBase = new DataBase();

        int selectedRow;
        public Inventory(checkUser user)
        {
            _user = user;
            InitializeComponent();
        }

        private void CreateColumns()
        {
            DGVInventory.Columns.Add("id", "id");
            DGVInventory.Columns.Add("NameInventory", "Название инвентаря");
            DGVInventory.Columns.Add("NumberOfInventory", "Количество инвентаря");
            DGVInventory.Columns.Add("Price", "Цена (в руб.)");
            DGVInventory.Columns.Add("IsNew", string.Empty);

            DGVInventory.Columns[0].Visible = false;
            DGVInventory.Columns[4].Visible = false;


            DGVInventory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void ClearTextBoxs()

        {
            TextBoxIDInventory.Text = "";
            TextBoxNameInventory.Text = "";
            TextBoxNumberOfInventory.Text = "";
            TextBoxPrice.Text = "";
        }

        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetInt32(2), record.GetDecimal(3), RowState.ModfieldNew);
        }

        private void RefresDataGrid(DataGridView dgw)
        {

            dgw.Rows.Clear();

            string queryString = $"select * from Inventory";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
    
        private void Inventory_Load(object sender, EventArgs e)
        {

            CreateColumns();
            RefresDataGrid(DGVInventory);
        }

        private void LeftBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenu mainmenu = new MainMenu(_user);
            mainmenu.ShowDialog();
        }

        private void PictureExit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите выйти?", "Предупреждение", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }

            else if (dialogResult == DialogResult.No)
            {

                return;
            }
        }

        private void LeftBack_MouseLeave(object sender, EventArgs e)
        {
            LeftBack.BackColor = Color.FromArgb(46, 109, 156);
        }

        private void LeftBack_MouseMove(object sender, MouseEventArgs e)
        {
            LeftBack.BackColor = Color.FromArgb(12, 82, 116);
        }

        private void PictureExit_MouseLeave(object sender, EventArgs e)
        {
            PictureExit.BackColor = Color.FromArgb(46, 109, 156);
        }

        private void PictureExit_MouseMove(object sender, MouseEventArgs e)
        {
            PictureExit.BackColor = Color.FromArgb(12, 82, 116);
        }

        private void DGVInventory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVInventory.Rows[selectedRow];
                TextBoxIDInventory.Text = row.Cells[0].Value.ToString();
                TextBoxNameInventory.Text = row.Cells[1].Value.ToString();
                TextBoxNumberOfInventory.Text = row.Cells[2].Value.ToString();
                TextBoxPrice.Text = row.Cells[3].Value.ToString();
            }
        }

        private void PictureRefreshTable_Click(object sender, EventArgs e)
        {
            RefresDataGrid(DGVInventory);
            ClearTextBoxs();
        }

        private void ButtonADD_Click(object sender, EventArgs e)
        {
            ADDInventory addinventory = new ADDInventory(_user);
            addinventory.ShowDialog();
        }


        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string searcString = $"select * from Inventory where concat (ID_Inventory, NameInventory, NumberOfInventory, Price) like '%" + TextBoxSearch.Text + "%'";

            SqlCommand com = new SqlCommand(searcString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }

            read.Close();
        }



        private void deleteRow()
        {
            int index = DGVInventory.CurrentCell.RowIndex;

            DGVInventory.Rows[index].Visible = false;

            if (DGVInventory.Rows[index].Cells[0].Value.ToString() == String.Empty)
            {
                DGVInventory.Rows[index].Cells[3].Value = RowState.Deleted;
                return;
            }
            DGVInventory.Rows[index].Cells[4].Value = RowState.Deleted;
        }
        private void TextBoxSearch_TextChanged(object sender, EventArgs e)
        {

            Search(DGVInventory);
        }


        private void Update()
        {
            dataBase.openConnection();
            for (int index = 0; index < DGVInventory.Rows.Count; index++)
            {
                var rowState = (RowState)DGVInventory.Rows[index].Cells[4].Value;

                if (rowState == RowState.Existed)
                    continue;

                if (rowState == RowState.Deleted)
                {
                    var id = Convert.ToInt32(DGVInventory.Rows[index].Cells[0].Value);

                    var deleteQuery = $"delete from Inventory where ID_Inventory = {id}";

                    var command = new SqlCommand(deleteQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();


                }

                if (rowState == RowState.Modfield)
                {
                    var id = DGVInventory.Rows[index].Cells[0].Value.ToString();
                    var name = DGVInventory.Rows[index].Cells[1].Value.ToString();
                    var number = DGVInventory.Rows[index].Cells[2].Value.ToString();
                    var price = DGVInventory.Rows[index].Cells[3].Value.ToString();

                    var changerQouery = $"update Inventory set NameInventory = '{name}', NumberOfInventory = '{number}', Price = '{price}' where ID_Inventory = '{id}'";

                    var command = new SqlCommand(changerQouery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите удалить запись?", "Предупреждение", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)


            {
                deleteRow();
                ClearTextBoxs();
            }

            else if (dialogResult == DialogResult.No)
            {

                return;
            }
        
        }

        private void ButtonSave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите сохранить изменения?", "Предупреждение", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)


            {
                Update();
            }

            else if (dialogResult == DialogResult.No)
            {

                return;
            }
        }

        private void Change()
        {
            var selectedRowIndex = DGVInventory.CurrentCell.RowIndex;

            var id = TextBoxIDInventory.Text;
            var name = TextBoxNameInventory.Text;
            int number;
            decimal price;
          

            if (DGVInventory.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {


                if (int.TryParse(TextBoxNumberOfInventory.Text, out number))
                    
 
                if (decimal.TryParse(TextBoxPrice.Text, out price))
                {
                    DGVInventory.Rows[selectedRowIndex].SetValues(id, name, number, price);
                    DGVInventory.Rows[selectedRowIndex].Cells[4].Value = RowState.Modfield;
                }

                else
                    {
                        MessageBox.Show("Цена должна иметь числовой формат!");
                    }

            }
        }
        private void ButtonChange_Click(object sender, EventArgs e)
        {

            if (TextBoxNameInventory.Text != string.Empty && TextBoxNumberOfInventory.Text != string.Empty && TextBoxPrice.Text != string.Empty)
            {
                Change();
                ClearTextBoxs();
            }
            else
            {
                MessageBox.Show("Одно из полей незаполнено");
            }



        }

        private void TextBoxNumberOfInventory_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)))
            {
                if (e.KeyChar != (char)Keys.Back)

                {
                    e.Handled = true;
                }
            }
        }

        private void TextBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)))
            {
                if (e.KeyChar != (char)Keys.Back)

                {
                    e.Handled = true;
                }
            }
        }
    }

}


