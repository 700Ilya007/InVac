﻿namespace InvAc
{
}

namespace InvAc
{


    public partial class Vedenie_UchetaDataSet1
    {
    }
}
namespace InvAc {
    
    
    public partial class Vedenie_UchetaDataSet1 {
    }
}
